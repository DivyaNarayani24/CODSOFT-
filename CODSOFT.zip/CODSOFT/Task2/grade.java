import java.util.Scanner;
class grade {
    double avg;
    double total;
    void average(double total, int n) {
        this.total = total;
        this.avg = total / n;
    }
    String grade() {
        if (avg >= 90) return "A";
        else if (avg >= 80) return "B";
        else if (avg >= 70) return "C";
        else if (avg >= 60) return "D";
        else if (avg >= 50) return "E";
        else return "F";
    }
    void display() {
        System.out.println("Total Marks: " + total);
        System.out.println("Average Percentage: " + avg);
        System.out.println("Grade: " + grade());
        if (grade().equals("F")) {
            System.out.println("The student got fail");
        } else {
            System.out.println("The student got pass");
        }
    }
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        grade ob = new grade();
        System.out.println("Enter number of subjects:");
        int n = s.nextInt();
        int marks;
        double total = 0;
        for (int i = 1; i <= n; i++) {
            System.out.println("Enter marks for subject " + i + ": ");
            marks = s.nextInt();
            if (marks >= 0 && marks <= 100) {
                total += marks;
            } else {
                System.out.println("Invalid marks");
            }
        }
        ob.average(total, n);
        ob.display();
    }
}
