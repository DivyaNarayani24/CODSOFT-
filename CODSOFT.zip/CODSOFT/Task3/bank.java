
import java.util.Scanner;

interface atm{
    abstract void withdrawing(int amount);
    abstract void depositing(int amount);
    abstract void toCheck();    
}
class account implements atm{
    int amount;
    public void withdrawing(int amount){
        if(amount<0){
            System.out.println("Amount should be positive integer");
            return;
        }
        if(this.amount<amount){
            System.out.println("Sorry,Insufficient Balance");
        }
        else{
            this.amount-=amount;
            System.out.println("Successfully withdrawn");
        }
    }
    public void depositing(int amount){
        if(amount<0){
            System.out.println("Amount should be positive integer");
            return;
        }
        this.amount+=amount;
        System.out.println("Successfully deposited");
    }
    public void toCheck(){
        System.out.println("Balance: "+amount);
    }
}
class bank{
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        account ob=new account();
        int money;
        int choice;
        do {
            System.out.println("Select your type");
            System.out.println("1. Withdrawal");
            System.out.println("2. Depositing");
            System.out.println("3. Check the Balance");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");
            choice = s.nextInt();
            switch (choice) {
                case 1:
                    System.out.println("Enter the amount");
                    money=s.nextInt();
                    ob.withdrawing(money);
                    break;
                case 2:
                    System.out.println("Enter the amount");
                    money=s.nextInt();
                    ob.depositing(money);
                    break;
                case 3:
                    ob.toCheck();
                    break;
                case 4:
                    System.out.println("Exiting....");
                    break;
                default:
                    System.out.println("Invalid choice! Please try again.");
            }
        } while (choice != 4); 
    }
}