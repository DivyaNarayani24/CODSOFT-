import java.util.Random; 
import java.util.Scanner;
class random{
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        Random r=new Random();
        String opinion;
        do{
        int n=r.nextInt(100);
        System.out.println(n);
        int n1,attempt=3;
        while(attempt!=0){
        System.out.println("Enter any number from 1 to 100");
        n1=s.nextInt();
        if(n>n1){
            System.out.println("Too low");
        }
        else if(n<n1){
            System.out.println("Too big");
        }
        else{
            System.out.println("Yess guessed");
            break;
        }
        attempt--;
        }
        if(attempt==0){
            System.out.println("Sorry attempts are over");
        }
        
        System.out.println("Wanna play again? 'Yes' or 'No'");
        opinion=s.next();
        }while(opinion.equalsIgnoreCase("yes"));
    }
}
