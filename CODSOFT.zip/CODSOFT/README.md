# CODSOFT Java Development Internship

This repository contains my completed tasks for the CODSOFT Java Development Internship.

## Task 1: Number Game
A console-based number guessing game where:
- A random number is generated between 1 and 100
- The user guesses until correct, with hints provided
- Limits the number of attempts and tracks the score

## Task 2: Student Grade Calculator
A Java program that:
- Takes marks for each subject
- Calculates total, average percentage
- Assigns and displays grades

## Task 3: ATM Interface
A Java-based ATM simulation that:
- Allows deposits, withdrawals, and balance checks
- Validates user input and handles insufficient balance cases

---

How to Run
1. Compile each .java file using:
  	javac FileName.java
2. Run the program using:
	java FileName

---


Author: Dhivya